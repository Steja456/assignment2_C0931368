package com.example.blog.services;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import com.example.blog.models.BlogPost;
import com.example.blog.models.Person;

public class Blog {
    private List<Person> persons;
    private List<BlogPost> blogPosts;

    public Blog(List<Person> persons, List<BlogPost> blogPosts) {
        this.persons = persons;
        this.blogPosts = blogPosts;
    }

    public List<String> getPostsByAuthorAge(Integer age) {
        Set<String> authorIds = persons.stream()
                .filter(p -> Objects.equals(p.getAge(), age))
                .map(Person::getId)
                .collect(Collectors.toSet());

        return blogPosts.stream()
                .filter(bp -> authorIds.contains(bp.getAuthorId()))
                .map(BlogPost::getId)
                .collect(Collectors.toList());
    }

    public long getTotalBlogPosts() {
        return blogPosts.size();
    }

    public long getTotalContributors() {
        return blogPosts.stream()
                .map(BlogPost::getAuthorId)
                .distinct()
                .count();
    }
}

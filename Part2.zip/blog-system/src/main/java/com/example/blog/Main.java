package com.example.blog;

import com.example.blog.models.BlogPost;
import com.example.blog.models.Person;
import com.example.blog.services.Blog;
import com.example.blog.utils.JsonUtils;
import com.fasterxml.jackson.core.type.TypeReference;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        String personPath = "src/main/resources/person.json";
        String blogPostPath = "src/main/resources/blogPosts.json";

        List<Person> persons = JsonUtils.readJson(personPath, new TypeReference<>() {});
        List<BlogPost> blogPosts = JsonUtils.readJson(blogPostPath, new TypeReference<>() {});

        Blog blog = new Blog(persons, blogPosts);

        System.out.println("Blog Post IDs by authors aged 30: " + blog.getPostsByAuthorAge(30));
        System.out.println("Total blog posts: " + blog.getTotalBlogPosts());
        System.out.println("Total contributors: " + blog.getTotalContributors());

        // Handle missing author ID cases
        blogPosts.stream()
                .filter(bp -> persons.stream().noneMatch(p -> p.getId().equals(bp.getAuthorId())))
                .forEach(bp -> System.out.println("⚠ Warning: BlogPost " + bp.getId() + " has no valid author."));
    }
}
